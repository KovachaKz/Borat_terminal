/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║         BORAT TERMINAL — VS CODE / CURSOR EXTENSION         ║
 * ║                                                             ║
 * ║  Watches every terminal in the IDE.                        ║
 * ║  Detects errors. Plays Borat. Very nice.                   ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import * as vscode from "vscode";
import * as path from "path";
import * as fs from "fs";
import { spawn, ChildProcess } from "child_process";
import { platform } from "os";

// ─────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────

type SoundCategory =
  | "permission_denied"
  | "command_not_found"
  | "connection_timeout"
  | "build_failed"
  | "crash"
  | "generic_error";

interface ErrorMatch {
  category: SoundCategory;
  snippet: string;
}

interface PluginConfig {
  enabled: boolean;
  volume: number;
  cooldownMs: number;
  soundsDir: string;
  sounds: Record<SoundCategory, string>;
  customPatterns: string[];
}

// ─────────────────────────────────────────────────────────────
// Error Pattern Engine
// ─────────────────────────────────────────────────────────────

const PATTERNS: Array<{ category: SoundCategory; patterns: RegExp[] }> = [
  {
    category: "permission_denied",
    patterns: [
      /permission denied/i,
      /access denied/i,
      /operation not permitted/i,
      /EACCES/,
      /you do not have.*permission/i,
      /sudo:.*incorrect password/i,
    ],
  },
  {
    category: "command_not_found",
    patterns: [
      /command not found/i,
      /not found.*command/i,
      /No such file or directory/,
      /is not recognized as.*command/i,
      /zsh:.*not found/i,
      /bash:.*command not found/i,
      /Cannot find module/,
      /ModuleNotFoundError/,
    ],
  },
  {
    category: "connection_timeout",
    patterns: [
      /connection timed? out/i,
      /connection refused/i,
      /network is unreachable/i,
      /no route to host/i,
      /could not resolve host/i,
      /ssl.*error/i,
      /certificate.*expired/i,
      /ECONNREFUSED/,
      /ETIMEDOUT/,
      /EHOSTUNREACH/,
    ],
  },
  {
    category: "build_failed",
    patterns: [
      /build failed/i,
      /FAILURE:.*build/i,
      /compilation failed/i,
      /make.*\*\*\*.*Error/,
      /gradle.*FAILED/i,
      /npm ERR!/,
      /yarn.*error/i,
      /error\[E\d+\]/,
      /error TS\d+:/,
      /SyntaxError:/,
      /ImportError:/,
    ],
  },
  {
    category: "crash",
    patterns: [
      /segmentation fault/i,
      /core dumped/i,
      /out of memory/i,
      /NullPointerException/,
      /OutOfMemoryError/,
      /StackOverflowError/,
      /fatal error/i,
      /panic:/i,
      /thread.*panicked/i,
      /CrashLoopBackOff/,
      /exited with code [1-9]/i,
      /process finished with exit code [1-9]/i,
    ],
  },
  {
    category: "generic_error",
    patterns: [
      /^\s*error:/im,
      /^\s*ERROR:/m,
      /FAILED$/m,
      /Traceback \(most recent/i,
      /AssertionError/,
      /TypeError:/,
      /ValueError:/,
      /AttributeError:/,
      /RuntimeError:/,
    ],
  },
];

const FALSE_POSITIVES: RegExp[] = [
  /^\s*#/,
  /error\.log/i,
  /error\.ts/i,
  /error\.js/i,
  /errorHandler/i,
  /\.error\s*\(/,
  /no errors/i,
  /0 errors/i,
  /catch\s*\(/,
  /except\s+/,
  /^\s*\^/,
];

const ANSI_STRIP = /\x1b\[[0-9;]*[mGKHF]|\x1b\][^\x07]*\x07/g;

function detectError(text: string): ErrorMatch | null {
  const clean = text.replace(ANSI_STRIP, "");
  const lines = clean.split(/\r?\n/);

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.length < 4) continue;
    if (FALSE_POSITIVES.some((fp) => fp.test(trimmed))) continue;

    for (const { category, patterns } of PATTERNS) {
      if (patterns.some((p) => p.test(trimmed))) {
        return { category, snippet: trimmed.slice(0, 100) };
      }
    }
  }
  return null;
}

// ─────────────────────────────────────────────────────────────
// Audio Player
// ─────────────────────────────────────────────────────────────

class AudioPlayer {
  private lastPlayedAt = 0;
  private activeProcess: ChildProcess | null = null;

  async play(soundPath: string, volume: number, cooldownMs: number): Promise<boolean> {
    const now = Date.now();
    if (now - this.lastPlayedAt < cooldownMs) return false;

    if (!fs.existsSync(soundPath)) {
      return false;
    }

    this.stop();
    this.lastPlayedAt = now;

    const cmd = this.buildCommand(soundPath, volume);
    if (!cmd) return false;

    try {
      const child = spawn(cmd.bin, cmd.args, {
        detached: true,
        stdio: "ignore",
        shell: process.platform === "win32",
        windowsHide: true,
      });
      child.unref();
      this.activeProcess = child;
      return true;
    } catch {
      return false;
    }
  }

  stop() {
    if (this.activeProcess) {
      try { this.activeProcess.kill("SIGTERM"); } catch {}
      this.activeProcess = null;
    }
  }

  private buildCommand(filePath: string, volume: number): { bin: string; args: string[] } | null {
    const os = process.platform;

    if (os === "darwin") {
      return { bin: "afplay", args: ["-v", volume.toFixed(2), filePath] };
    }

    if (os === "linux") {
      // Try mpg123, paplay, ffplay in order
      const players = [
        { bin: "mpg123", args: ["-q", "--scale", String(Math.round(volume * 32768)), filePath] },
        { bin: "paplay", args: [`--volume=${Math.round(volume * 65536)}`, filePath] },
        { bin: "ffplay", args: ["-nodisp", "-autoexit", "-volume", String(Math.round(volume * 100)), "-loglevel", "quiet", filePath] },
      ];
      // Return first one (runtime will fail gracefully if not installed)
      return players[0];
    }

    if (os === "win32") {
      const escaped = filePath.replace(/'/g, "''");
      const script = [
        "Add-Type -AssemblyName PresentationCore;",
        `$p=New-Object System.Windows.Media.MediaPlayer;`,
        `$p.Open([Uri]::new('${escaped}'));`,
        `$p.Volume=${volume.toFixed(2)};`,
        `Start-Sleep -Ms 200; $p.Play();`,
        `Start-Sleep -Sec 60; $p.Close();`,
      ].join(" ");
      return { bin: "powershell", args: ["-NoProfile", "-WindowStyle", "Hidden", "-Command", script] };
    }

    return null;
  }
}

// ─────────────────────────────────────────────────────────────
// Config
// ─────────────────────────────────────────────────────────────

function loadConfig(extensionPath: string): PluginConfig {
  const cfg = vscode.workspace.getConfiguration("boratTerminal");
  const defaultSoundsDir = path.join(extensionPath, "sounds");

  return {
    enabled: cfg.get<boolean>("enabled", true),
    volume: Math.min(1, Math.max(0, cfg.get<number>("volume", 0.85))),
    cooldownMs: Math.max(0, cfg.get<number>("cooldownMs", 3000)),
    soundsDir: cfg.get<string>("soundsDir", defaultSoundsDir),
    customPatterns: cfg.get<string[]>("customPatterns", []),
    sounds: {
      permission_denied: cfg.get<string>("sounds.permission_denied", "permission_denied.mp3"),
      command_not_found: cfg.get<string>("sounds.command_not_found", "command_not_found.mp3"),
      connection_timeout: cfg.get<string>("sounds.connection_timeout", "connection_timeout.mp3"),
      build_failed: cfg.get<string>("sounds.build_failed", "build_failed.mp3"),
      crash: cfg.get<string>("sounds.crash", "crash.mp3"),
      generic_error: cfg.get<string>("sounds.generic_error", "generic_error.mp3"),
    },
  };
}

function resolveSoundPath(config: PluginConfig, category: SoundCategory): string | null {
  const filename = config.sounds[category] || config.sounds.generic_error;
  if (!filename) return null;

  const fullPath = path.join(config.soundsDir, filename);
  if (fs.existsSync(fullPath)) return fullPath;

  // Try generic_error as fallback
  const fallback = path.join(config.soundsDir, config.sounds.generic_error);
  if (fs.existsSync(fallback)) return fallback;

  // Any mp3 in the dir
  try {
    const mp3s = fs.readdirSync(config.soundsDir).filter((f) => f.endsWith(".mp3"));
    if (mp3s.length > 0) return path.join(config.soundsDir, mp3s[0]);
  } catch {}

  return null;
}

// ─────────────────────────────────────────────────────────────
// Extension Activation
// ─────────────────────────────────────────────────────────────

let outputChannel: vscode.OutputChannel;
let audioPlayer: AudioPlayer;
let errorCount = 0;

export function activate(context: vscode.ExtensionContext): void {
  outputChannel = vscode.window.createOutputChannel("Borat Terminal");
  audioPlayer = new AudioPlayer();

  log("🇰🇿 Kazakhstan OS Error Detection System — ACTIVATED");
  log(`Sounds directory: ${path.join(context.extensionPath, "sounds")}`);

  let config = loadConfig(context.extensionPath);

  // Validate sound files on startup
  validateSounds(config, context.extensionPath);

  // ── Terminal output hook ──────────────────────────────────
  // onDidWriteTerminalData fires for every chunk written to any terminal
  const writeHandler = (vscode.window as any).onDidWriteTerminalData;

  if (typeof writeHandler === "function") {
    const disposable = writeHandler.call(
      vscode.window,
      (e: { terminal: vscode.Terminal; data: string }) => {
        if (!config.enabled) return;
        handleOutput(e.data, config, context.extensionPath);
      }
    );
    context.subscriptions.push(disposable);
    log("Hooked into terminal data stream ✓");
  } else {
    // Fallback: shell integration exit code detection
    const exitHandler = (vscode.window as any).onDidEndTerminalShellExecution;
    if (typeof exitHandler === "function") {
      context.subscriptions.push(
        exitHandler.call(
          vscode.window,
          (e: { exitCode?: number }) => {
            if (e.exitCode && e.exitCode !== 0) {
              handleOutput(`exit code ${e.exitCode}`, config, context.extensionPath);
            }
          }
        )
      );
      log("Hooked into shell exit codes (fallback mode) ✓");
    }
  }

  // ── Config hot-reload ─────────────────────────────────────
  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration((e) => {
      if (e.affectsConfiguration("boratTerminal")) {
        config = loadConfig(context.extensionPath);
        log("Config reloaded");
      }
    })
  );

  // ── Commands ──────────────────────────────────────────────
  context.subscriptions.push(
    vscode.commands.registerCommand("boratTerminal.test", () => {
      handleOutput("Error: permission denied", config, context.extensionPath);
      vscode.window.showInformationMessage("🇰🇿 Borat: Test error triggered!");
    }),

    vscode.commands.registerCommand("boratTerminal.testCategory", async () => {
      const categories: SoundCategory[] = [
        "permission_denied", "command_not_found", "connection_timeout",
        "build_failed", "crash", "generic_error",
      ];
      const pick = await vscode.window.showQuickPick(categories, {
        placeHolder: "Choose error category to test",
      });
      if (pick) {
        const soundPath = resolveSoundPath(config, pick as SoundCategory);
        if (soundPath) {
          audioPlayer.play(soundPath, config.volume, 0);
          vscode.window.showInformationMessage(`🎵 Playing: ${pick}`);
        } else {
          vscode.window.showWarningMessage(`No sound file found for: ${pick}`);
        }
      }
    }),

    vscode.commands.registerCommand("boratTerminal.toggle", () => {
      const cfg = vscode.workspace.getConfiguration("boratTerminal");
      const current = cfg.get<boolean>("enabled", true);
      cfg.update("enabled", !current, vscode.ConfigurationTarget.Global);
      const state = !current ? "ENABLED 🇰🇿" : "DISABLED 🔇";
      vscode.window.showInformationMessage(`Borat Terminal: ${state}`);
    }),

    vscode.commands.registerCommand("boratTerminal.showStats", () => {
      vscode.window.showInformationMessage(
        `🇰🇿 Borat has detected ${errorCount} errors since activation. Very not nice.`
      );
    }),

    vscode.commands.registerCommand("boratTerminal.openConfig", () => {
      vscode.commands.executeCommand(
        "workbench.action.openSettings",
        "boratTerminal"
      );
    })
  );

  // ── Status bar ────────────────────────────────────────────
  const statusBar = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Right,
    100
  );
  statusBar.text = "🇰🇿 Borat";
  statusBar.tooltip = "Borat Terminal Error Notifications — click to toggle";
  statusBar.command = "boratTerminal.toggle";
  statusBar.show();
  context.subscriptions.push(statusBar);

  // Update status bar on config change
  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration(() => {
      const enabled = vscode.workspace.getConfiguration("boratTerminal").get("enabled", true);
      statusBar.text = enabled ? "🇰🇿 Borat" : "🔇 Borat";
    })
  );

  context.subscriptions.push({
    dispose: () => {
      audioPlayer.stop();
      outputChannel.dispose();
    },
  });
}

export function deactivate(): void {
  audioPlayer?.stop();
}

// ─────────────────────────────────────────────────────────────
// Core handler
// ─────────────────────────────────────────────────────────────

function handleOutput(data: string, config: PluginConfig, extensionPath: string): void {
  const match = detectError(data);
  if (!match) return;

  errorCount++;
  log(`[${match.category}] ${match.snippet}`);

  const soundPath = resolveSoundPath(config, match.category);
  if (!soundPath) {
    log(`No sound file for: ${match.category} — add MP3 to ${config.soundsDir}`);
    return;
  }

  audioPlayer.play(soundPath, config.volume, config.cooldownMs).then((played) => {
    if (played) {
      log(`♪ Played ${path.basename(soundPath)}`);
    }
  });
}

function validateSounds(config: PluginConfig, extensionPath: string): void {
  const dir = config.soundsDir;
  if (!fs.existsSync(dir)) {
    log(`⚠ Sounds directory not found: ${dir}`);
    log(`  Create it and add MP3 files named: ${Object.values(config.sounds).join(", ")}`);
    vscode.window.showWarningMessage(
      `Borat Terminal: No sounds directory found. Add MP3 files to: ${dir}`,
      "Open Settings"
    ).then((choice) => {
      if (choice === "Open Settings") {
        vscode.commands.executeCommand("boratTerminal.openConfig");
      }
    });
    return;
  }

  const missing: string[] = [];
  for (const [cat, file] of Object.entries(config.sounds)) {
    const p = path.join(dir, file);
    if (!fs.existsSync(p)) {
      missing.push(`${cat}: ${file}`);
    }
  }

  if (missing.length > 0) {
    log(`⚠ Missing sound files:\n  ${missing.join("\n  ")}`);
  } else {
    log("All sound files present ✓");
  }
}

function log(msg: string): void {
  const ts = new Date().toTimeString().slice(0, 8);
  outputChannel.appendLine(`[${ts}] ${msg}`);
}
