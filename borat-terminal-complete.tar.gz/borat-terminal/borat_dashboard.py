#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════╗
║            BORAT TERMINAL — LIVE DASHBOARD                      ║
║            Kazakhstan Ministry of Error Detection               ║
║                                                                 ║
║  Real-time monitoring dashboard.                               ║
║  Shows error feed, stats, sound status, and controls.          ║
║  Pure Python — no dependencies beyond stdlib.                  ║
╚══════════════════════════════════════════════════════════════════╝
"""

import curses
import json
import time
import os
import sys
import threading
import subprocess
import signal
from pathlib import Path
from datetime import datetime
from collections import deque
from typing import Optional

# Re-use core components from daemon
sys.path.insert(0, str(Path(__file__).parent))
try:
    from borat_daemon import (
        load_config, resolve_sound, detect_error, ErrorStats,
        AudioPlayer, SOUNDS_DIR, CONFIG_PATH, strip_ansi
    )
    DAEMON_AVAILABLE = True
except ImportError:
    DAEMON_AVAILABLE = False

# ─────────────────────────────────────────────────────────────
# Color scheme — Kazakhstan flag palette + terminal green
# ─────────────────────────────────────────────────────────────

C_DEFAULT  = 0
C_HEADER   = 1   # Kazakhstan blue on black
C_ACTIVE   = 2   # Bright yellow (flag gold)
C_ERROR    = 3   # Red
C_SUCCESS  = 4   # Green
C_DIM      = 5   # Gray
C_CATEGORY = 6   # Cyan
C_BORDER   = 7   # Dark blue
C_TITLE    = 8   # White bold

CATEGORY_ICONS = {
    "permission_denied":  "🔒",
    "command_not_found":  "❓",
    "connection_timeout": "🌐",
    "build_failed":       "🔨",
    "crash":              "💀",
    "generic_error":      "⚠️ ",
}

BORAT_QUOTES = [
    "Very nice! Your code is NOT very nice.",
    "I like! But your stack trace, I do not like.",
    "High five! ...Actually no. Not high five. Big error.",
    "Is nice! But then ERROR. Not nice.",
    "My neighbour Nursultan Tulyakbay write better code. He is farmer.",
    "The memory has dump in the well!",
    "Kazakhstan number one exporter of errors.",
    "Wawaweewa! This program is broken!",
    "Error Code: VERY_NOT_NICE",
    "Chenquyeh! (That mean 'your build is fail')",
]

# ─────────────────────────────────────────────────────────────
# Dashboard
# ─────────────────────────────────────────────────────────────

class Dashboard:
    def __init__(self, stdscr: curses.window):
        self.scr = stdscr
        self.config = load_config() if DAEMON_AVAILABLE else {}
        self.audio = AudioPlayer() if DAEMON_AVAILABLE else None
        self.stats = ErrorStats() if DAEMON_AVAILABLE else None

        # Live feed
        self.events: deque = deque(maxlen=100)
        self.lock = threading.Lock()

        # UI state
        self.running = True
        self.selected_category = 0
        self.quote_index = 0
        self.quote_timer = time.time()
        self.last_event_time: Optional[float] = None
        self.paused = False

        # Category list for navigation
        self.categories = [
            "permission_denied",
            "command_not_found",
            "connection_timeout",
            "build_failed",
            "crash",
            "generic_error",
        ]

        self._init_colors()
        self._setup_signal()

    def _init_colors(self):
        curses.start_color()
        curses.use_default_colors()
        curses.init_pair(C_HEADER,   curses.COLOR_CYAN,   -1)
        curses.init_pair(C_ACTIVE,   curses.COLOR_YELLOW, -1)
        curses.init_pair(C_ERROR,    curses.COLOR_RED,    -1)
        curses.init_pair(C_SUCCESS,  curses.COLOR_GREEN,  -1)
        curses.init_pair(C_DIM,      curses.COLOR_WHITE,  -1)
        curses.init_pair(C_CATEGORY, curses.COLOR_CYAN,   -1)
        curses.init_pair(C_BORDER,   curses.COLOR_BLUE,   -1)
        curses.init_pair(C_TITLE,    curses.COLOR_WHITE,  -1)

    def _setup_signal(self):
        signal.signal(signal.SIGINT, lambda s, f: self._quit())

    def _quit(self):
        self.running = False

    # ── Rendering ─────────────────────────────────────────────

    def run(self):
        curses.curs_set(0)
        self.scr.nodelay(True)
        self.scr.keypad(True)

        # Start a background thread that simulates reading from a log/pipe
        watcher = threading.Thread(target=self._watch_log, daemon=True)
        watcher.start()

        while self.running:
            try:
                self._render()
                self._handle_input()
                time.sleep(0.05)
            except curses.error:
                pass
            except Exception:
                pass

    def _render(self):
        self.scr.erase()
        h, w = self.scr.getmaxyx()

        if h < 20 or w < 70:
            self._render_too_small(h, w)
            self.scr.refresh()
            return

        # Layout
        header_h    = 4
        stats_h     = 10
        footer_h    = 3
        feed_h      = h - header_h - footer_h - 1
        sidebar_w   = 28
        feed_w      = w - sidebar_w - 1

        self._render_header(0, 0, header_h, w)
        self._render_feed(header_h, 0, feed_h, feed_w)
        self._render_sidebar(header_h, feed_w + 1, feed_h, sidebar_w)
        self._render_footer(h - footer_h, 0, footer_h, w)

        self.scr.refresh()

    def _render_header(self, y, x, h, w):
        scr = self.scr

        # Title bar
        title = " 🇰🇿  BORAT TERMINAL — KAZAKHSTAN MINISTRY OF ERROR DETECTION  🇰🇿 "
        self._hline(y, 0, w, C_HEADER)

        tx = max(0, (w - len(title)) // 2)
        try:
            scr.addstr(y, tx, title, curses.color_pair(C_HEADER) | curses.A_BOLD)
        except curses.error:
            pass

        # Rotating quote
        now = time.time()
        if now - self.quote_timer > 8:
            self.quote_index = (self.quote_index + 1) % len(BORAT_QUOTES)
            self.quote_timer = now

        quote = f'"{BORAT_QUOTES[self.quote_index]}"'
        qx = max(0, (w - len(quote)) // 2)
        try:
            scr.addstr(y + 1, qx, quote[:w-1], curses.color_pair(C_ACTIVE))
        except curses.error:
            pass

        # Status line
        enabled = self.config.get("enabled", True)
        vol = self.config.get("volume", 0.85)
        cool = self.config.get("cooldown_ms", 3000)
        total = self.stats.total if self.stats else 0
        status_str = (
            f"  Status: {'● ACTIVE' if enabled else '○ PAUSED'}  │"
            f"  Volume: {vol:.0%}  │"
            f"  Cooldown: {cool}ms  │"
            f"  Errors caught: {total}  │"
            f"  Sounds: {SOUNDS_DIR.name}"
        )
        color = C_SUCCESS if enabled else C_DIM
        try:
            scr.addstr(y + 2, 0, status_str[:w-1], curses.color_pair(color))
        except curses.error:
            pass

        # Divider
        self._hline(y + 3, 0, w, C_BORDER)

    def _render_feed(self, y, x, h, w):
        scr = self.scr
        # Box title
        title = "[ LIVE ERROR FEED ]"
        try:
            scr.addstr(y, x + 2, title, curses.color_pair(C_HEADER) | curses.A_BOLD)
        except curses.error:
            pass

        with self.lock:
            events = list(self.events)[-( h - 2):]

        for i, event in enumerate(events):
            ey = y + 1 + i
            if ey >= y + h - 1:
                break

            ts        = event.get("ts", "??:??:??")
            category  = event.get("category", "unknown")
            snippet   = event.get("snippet", "")
            icon      = CATEGORY_ICONS.get(category, "⚡")
            played    = event.get("played", False)

            # Color by category
            cat_color = {
                "permission_denied":  C_ACTIVE,
                "command_not_found":  C_DIM,
                "connection_timeout": C_CATEGORY,
                "build_failed":       C_ERROR,
                "crash":              C_ERROR,
                "generic_error":      C_DIM,
            }.get(category, C_DIM)

            sound_indicator = "♪" if played else " "
            line = f" {ts} {icon} {category:<20} {sound_indicator} {snippet}"
            try:
                scr.addstr(ey, x, line[:w-1], curses.color_pair(cat_color))
            except curses.error:
                pass

        # Empty state
        if not events:
            msg = "No errors detected yet. Kazakhstan OS is stable. Very nice!"
            my = y + h // 2
            mx = x + max(0, (w - len(msg)) // 2)
            try:
                scr.addstr(my, mx, msg, curses.color_pair(C_DIM) | curses.A_DIM)
            except curses.error:
                pass

        # Right border
        for row in range(y, y + h):
            try:
                scr.addstr(row, x + w, "│", curses.color_pair(C_BORDER))
            except curses.error:
                pass

    def _render_sidebar(self, y, x, h, w):
        scr = self.scr

        # Title
        try:
            scr.addstr(y, x + 1, "[ SOUND CONTROLS ]",
                       curses.color_pair(C_HEADER) | curses.A_BOLD)
        except curses.error:
            pass

        # Category list with sound status
        for i, cat in enumerate(self.categories):
            row = y + 2 + i * 2
            if row >= y + h - 4:
                break

            icon    = CATEGORY_ICONS.get(cat, "⚡")
            sound_f = self.config.get("sounds", {}).get(cat, cat + ".mp3")
            sound_p = SOUNDS_DIR / sound_f
            exists  = sound_p.exists()

            is_sel  = (i == self.selected_category)
            marker  = "▶ " if is_sel else "  "
            file_ok = "✓" if exists else "✗"
            f_color = C_SUCCESS if exists else C_ERROR
            sel_attr = curses.A_REVERSE if is_sel else 0

            cat_short = cat.replace("_", " ").title()[:16]
            line = f"{marker}{icon} {cat_short}"
            try:
                scr.addstr(row, x, line[:w-1],
                            curses.color_pair(C_ACTIVE) | sel_attr)
                scr.addstr(row, x + w - 3, f" {file_ok} ",
                            curses.color_pair(f_color))
            except curses.error:
                pass

            # File name hint
            fname_hint = sound_f[:w - 3]
            try:
                scr.addstr(row + 1, x + 2, fname_hint,
                            curses.color_pair(C_DIM) | curses.A_DIM)
            except curses.error:
                pass

        # Stats block
        stats_y = y + h - 10
        if self.stats and stats_y > y + len(self.categories) * 2 + 3:
            try:
                scr.addstr(stats_y, x + 1, "[ ERROR COUNTS ]",
                            curses.color_pair(C_HEADER))
            except curses.error:
                pass

            for j, cat in enumerate(self.categories):
                count = self.stats.by_category.get(cat, 0)
                row   = stats_y + 1 + j
                if row >= y + h - 1:
                    break
                bar_w = min(count, w - 14)
                bar   = "█" * bar_w
                try:
                    scr.addstr(row, x + 1,
                                f"{cat[:12]:<12} {count:>3} {bar}",
                                curses.color_pair(C_CATEGORY if count > 0 else C_DIM))
                except curses.error:
                    pass

    def _render_footer(self, y, x, h, w):
        scr = self.scr
        self._hline(y, 0, w, C_BORDER)

        keys = (
            " [↑↓] Select  [ENTER/SPACE] Test Sound  "
            "[P] Pause  [C] Clear  [+/-] Volume  [Q] Quit "
        )
        try:
            scr.addstr(y + 1, 0, keys[:w-1], curses.color_pair(C_DIM))
        except curses.error:
            pass

        # Right-align time
        ts = datetime.now().strftime("%H:%M:%S")
        try:
            scr.addstr(y + 1, w - 10, ts, curses.color_pair(C_DIM))
        except curses.error:
            pass

    def _render_too_small(self, h, w):
        msg = "Terminal too small! Resize to at least 70x20."
        try:
            self.scr.addstr(h // 2, max(0, (w - len(msg)) // 2), msg)
        except curses.error:
            pass

    # ── Input ──────────────────────────────────────────────────

    def _handle_input(self):
        try:
            key = self.scr.getch()
        except curses.error:
            return

        if key == -1:
            return

        if key in (ord('q'), ord('Q'), 27):
            self._quit()

        elif key == curses.KEY_UP:
            self.selected_category = max(0, self.selected_category - 1)

        elif key == curses.KEY_DOWN:
            self.selected_category = min(len(self.categories) - 1,
                                          self.selected_category + 1)

        elif key in (ord(' '), ord('\n'), curses.KEY_ENTER, 10):
            self._test_selected_sound()

        elif key in (ord('p'), ord('P')):
            self.config["enabled"] = not self.config.get("enabled", True)
            self.paused = not self.config["enabled"]

        elif key in (ord('c'), ord('C')):
            with self.lock:
                self.events.clear()
            if self.stats:
                self.stats.total = 0
                self.stats.by_category.clear()

        elif key == ord('+'):
            vol = min(1.0, self.config.get("volume", 0.85) + 0.05)
            self.config["volume"] = round(vol, 2)

        elif key == ord('-'):
            vol = max(0.0, self.config.get("volume", 0.85) - 0.05)
            self.config["volume"] = round(vol, 2)

        elif key in (ord('r'), ord('R')):
            self.config = load_config()

    def _test_selected_sound(self):
        if not self.audio:
            return
        cat = self.categories[self.selected_category]
        sound_path = resolve_sound(self.config, cat)
        if sound_path:
            self.audio.play(sound_path, self.config.get("volume", 0.85), 0, cat)
            self._add_event(cat, f"[TEST] Manually triggered: {cat}", played=True)

    # ── Log watcher ────────────────────────────────────────────

    def _watch_log(self):
        """Watch the borat log file for new error events."""
        log_path = Path.home() / ".config" / "borat-terminal" / "borat.log"
        last_pos = 0

        while self.running:
            try:
                if log_path.exists():
                    with open(log_path, "r") as f:
                        f.seek(last_pos)
                        for line in f:
                            line = line.strip()
                            if "[INFO]" in line and "Error detected" in line:
                                # Parse: 2024-01-01 12:34:56,789 [INFO] Error detected [category]: snippet
                                try:
                                    bracket_start = line.index("[", line.index("detected"))
                                    bracket_end = line.index("]", bracket_start)
                                    cat = line[bracket_start + 1:bracket_end]
                                    snippet = line[bracket_end + 3:].strip()
                                    played = "Played" in line
                                    ts = line[11:19] if len(line) > 19 else "??:??:??"
                                    self._add_event(cat, snippet, played=played, ts=ts)
                                except (ValueError, IndexError):
                                    pass
                        last_pos = f.tell()
            except Exception:
                pass

            time.sleep(0.3)

    def _add_event(self, category: str, snippet: str, played: bool = False, ts: str = ""):
        if not ts:
            ts = datetime.now().strftime("%H:%M:%S")
        with self.lock:
            self.events.append({
                "ts": ts,
                "category": category,
                "snippet": snippet[:80],
                "played": played,
            })
        if self.stats:
            self.stats.record(category, snippet)
        self.last_event_time = time.time()

    # ── Helpers ────────────────────────────────────────────────

    def _hline(self, y: int, x: int, w: int, color: int):
        try:
            self.scr.addstr(y, x, "─" * (w - 1), curses.color_pair(color))
        except curses.error:
            pass


# ─────────────────────────────────────────────────────────────
# Entry
# ─────────────────────────────────────────────────────────────

def main():
    if not DAEMON_AVAILABLE:
        print("Error: borat_daemon.py must be in the same directory.")
        sys.exit(1)

    def run(stdscr):
        dash = Dashboard(stdscr)
        dash.run()

    try:
        curses.wrapper(run)
    except KeyboardInterrupt:
        pass

    print("\n🇰🇿 Kazakhstan OS dashboard closed. Chenquyeh!\n")


if __name__ == "__main__":
    main()
