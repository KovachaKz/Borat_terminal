# 🇰🇿 Borat Terminal — Kazakhstan OS Error Notification System

> *"I will watch your terminal output. Very nice."*

A cross-platform terminal error notification plugin that plays Borat voice clips whenever your terminal hits an error. Works as a **standalone shell wrapper**, a **VS Code/Cursor extension**, and includes a **live monitoring dashboard**.

---

## Architecture — How It Actually Works

```
┌─────────────────────────────────────────────────────────────────┐
│                        YOUR TERMINAL                            │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │                   PTY MASTER (Parent)                    │  │
│  │                                                          │  │
│  │   stdin ──► PTY slave ──► your shell (bash/zsh/fish)    │  │
│  │                │                                         │  │
│  │                ▼                                         │  │
│  │         Output interceptor                               │  │
│  │                │                                         │  │
│  │        ┌───────┴───────┐                                 │  │
│  │        │ Error Detector │  ← 60+ regex patterns          │  │
│  │        └───────┬───────┘    6 categories                 │  │
│  │                │                                         │  │
│  │       Match?   ├─ No  → stdout (transparent passthrough) │  │
│  │                │                                         │  │
│  │               Yes                                        │  │
│  │                │                                         │  │
│  │        ┌───────▼───────┐                                 │  │
│  │        │ Sound Resolver │  ← Maps category → MP3 file    │  │
│  │        └───────┬───────┘                                 │  │
│  │                │                                         │  │
│  │        ┌───────▼───────┐                                 │  │
│  │        │  Audio Player  │  ← Detached OS process         │  │
│  │        │  afplay/mpg123 │    Non-blocking                 │  │
│  │        └───────────────┘    Cooldown-gated               │  │
│  │                                                          │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

**Key design decisions:**
- **PTY wrapper** (not a shell plugin) — works with ANY shell, in ANY IDE terminal, transparently
- **Detached audio process** — playback never blocks your terminal
- **Per-category sounds** — `permission_denied` plays a different clip than `build_failed`
- **Smart cooldown** — won't fire 40 times during a gradle failure cascade
- **False-positive filter** — `error.ts`, `console.error()`, `no errors` won't trigger it

---

## Installation

### One command:
```bash
git clone https://github.com/youruser/borat-terminal.git
cd borat-terminal
bash install.sh
```

### With your existing MP3 files:
```bash
bash install.sh --sounds-dir /path/to/your/mp3s
```

### IDE extensions only:
```bash
bash install.sh --ide vscode   # VS Code
bash install.sh --ide cursor   # Cursor
bash install.sh --ide all      # Both
```

---

## Sound File Setup

Place MP3 files in `~/.config/borat-terminal/sounds/` named:

| Filename | Triggers on |
|---|---|
| `permission_denied.mp3` | Permission errors, sudo failures, EACCES |
| `command_not_found.mp3` | Unknown commands, missing modules |
| `connection_timeout.mp3` | Network errors, SSL, DNS failures |
| `build_failed.mp3` | npm/gradle/make/rustc/tsc failures |
| `crash.mp3` | Segfaults, OOM, panics, NullPointerException |
| `generic_error.mp3` | Catch-all fallback |

The installer will copy your MP3s automatically if you use `--sounds-dir`.

---

## Usage

### Shell wrapper mode (recommended)
```bash
borat           # Launches your shell inside the Borat wrapper
# Everything works exactly as before — errors just trigger sounds
exit            # Exit Borat wrapper (returns to parent shell)
```

### Live dashboard
```bash
borat-dash      # Opens the TUI monitoring dashboard
```

Dashboard controls:
- `↑ ↓` — Navigate sound categories
- `ENTER / SPACE` — Test selected sound
- `+ / -` — Adjust volume live
- `P` — Pause/resume detection
- `C` — Clear feed
- `Q` — Quit

### VS Code / Cursor
After installing the extension, it activates automatically.

Command palette (`Ctrl+Shift+P`):
- `Borat: Test Error Sound` — fires a test
- `Borat: Test Specific Sound Category` — pick from list
- `Borat: Toggle On/Off` — enable/disable
- `Borat: Show Error Stats` — how many errors caught

Status bar: click `🇰🇿 Borat` to toggle on/off.

### Testing
```bash
borat --test crash              # Test crash sound
borat --test permission_denied  # Test permission sound
borat --status                  # Show config and sound file status
borat --config                  # Show full config JSON
```

---

## Configuration

Config file: `~/.config/borat-terminal/config.json`

```json
{
  "enabled": true,
  "volume": 0.85,
  "cooldown_ms": 3000,
  "log_errors": true,
  "show_banner": true,
  "sounds": {
    "permission_denied":  "permission_denied.mp3",
    "command_not_found":  "command_not_found.mp3",
    "connection_timeout": "connection_timeout.mp3",
    "build_failed":       "build_failed.mp3",
    "crash":              "crash.mp3",
    "generic_error":      "generic_error.mp3"
  }
}
```

**`cooldown_ms`** — minimum gap between sounds. Set to `0` to disable. Recommended: `3000` (3 seconds) — prevents 40 sounds during a gradle failure.

---

## Platform Audio Requirements

| Platform | Player | Ships with? |
|---|---|---|
| macOS | `afplay` | ✓ Built-in |
| Linux | `mpg123` | `sudo apt install mpg123` |
| Linux (alt) | `paplay` | Usually pre-installed with PulseAudio |
| Windows | PowerShell MediaPlayer | ✓ Built-in |

The installer auto-detects and installs `mpg123` on Debian/Ubuntu/Fedora/Arch.

---

## Error Categories & Patterns

| Category | Example triggers |
|---|---|
| `permission_denied` | `Permission denied`, `Access denied`, `EACCES`, `sudo: incorrect password` |
| `command_not_found` | `command not found`, `No such file or directory`, `Cannot find module` |
| `connection_timeout` | `Connection timed out`, `ECONNREFUSED`, `SSL error`, `certificate expired` |
| `build_failed` | `BUILD FAILED`, `npm ERR!`, `compilation failed`, `error TS2345` |
| `crash` | `Segmentation fault`, `NullPointerException`, `panic:`, `OOMKilled` |
| `generic_error` | `Error:`, `Traceback`, `TypeError`, `AssertionError` |

---

## File Layout

```
~/.config/borat-terminal/
├── config.json           ← Your configuration
├── borat_daemon.py       ← Core detection engine
├── borat_dashboard.py    ← TUI dashboard
├── borat.log             ← Error history
└── sounds/
    ├── permission_denied.mp3
    ├── command_not_found.mp3
    ├── connection_timeout.mp3
    ├── build_failed.mp3
    ├── crash.mp3
    └── generic_error.mp3

~/.local/bin/
├── borat                 ← CLI entry point
└── borat-dash            ← Dashboard entry point
```

---

## License

MIT — Do whatever you want with it. Very nice.
