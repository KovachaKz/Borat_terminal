#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════════════════════╗
# ║          BORAT TERMINAL — ONE-COMMAND INSTALLER                 ║
# ║          "I will install this. Very nice."                      ║
# ╚══════════════════════════════════════════════════════════════════╝
#
# Usage:
#   bash install.sh                    # Full install
#   bash install.sh --sounds-dir /path # Specify existing sounds
#   bash install.sh --ide vscode       # Install only VS Code extension
#   bash install.sh --ide cursor       # Install only Cursor extension
#   bash install.sh --ide all          # Install all IDE extensions
#
set -euo pipefail

# ── Colors ────────────────────────────────────────────────────────
YL='\033[33m'; GN='\033[32m'; RD='\033[31m'; CY='\033[36m'; NC='\033[0m'; BD='\033[1m'

# ── Defaults ──────────────────────────────────────────────────────
INSTALL_DIR="$HOME/.config/borat-terminal"
SOUNDS_DIR="$INSTALL_DIR/sounds"
BIN_DIR="$HOME/.local/bin"
IDE_TARGET="all"
CUSTOM_SOUNDS=""

# ── Argument parsing ──────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case $1 in
    --sounds-dir) CUSTOM_SOUNDS="$2"; shift 2 ;;
    --ide)        IDE_TARGET="$2";    shift 2 ;;
    --help)       show_help; exit 0 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ── Banner ────────────────────────────────────────────────────────
echo ""
echo -e "${YL}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${YL}║  🇰🇿  BORAT TERMINAL ERROR NOTIFICATION SYSTEM              ║${NC}"
echo -e "${YL}║       Installation for Kazakhstan OS                        ║${NC}"
echo -e "${YL}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

step() { echo -e "${CY}▶ $1${NC}"; }
ok()   { echo -e "${GN}  ✓ $1${NC}"; }
warn() { echo -e "${YL}  ⚠ $1${NC}"; }
err()  { echo -e "${RD}  ✗ $1${NC}"; }

# ── Detect OS ─────────────────────────────────────────────────────
OS="$(uname -s)"
case "$OS" in
  Darwin) PLATFORM="macos" ;;
  Linux)  PLATFORM="linux" ;;
  CYGWIN*|MINGW*|MSYS*) PLATFORM="windows" ;;
  *) PLATFORM="unknown" ;;
esac
ok "Platform detected: $PLATFORM"

# ── Python check ──────────────────────────────────────────────────
step "Checking Python 3..."
if ! command -v python3 &>/dev/null; then
  err "Python 3 is required but not found."
  echo "  Install from https://python.org or via your package manager."
  exit 1
fi
PYVER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
ok "Python $PYVER found"

# ── Audio player check ────────────────────────────────────────────
step "Checking audio player..."
if [[ "$PLATFORM" == "macos" ]]; then
  ok "afplay (built-in) — no install needed"
elif [[ "$PLATFORM" == "linux" ]]; then
  if command -v mpg123 &>/dev/null; then
    ok "mpg123 found"
  elif command -v paplay &>/dev/null; then
    ok "paplay found"
  elif command -v ffplay &>/dev/null; then
    ok "ffplay found"
  else
    warn "No MP3 player found. Installing mpg123..."
    if command -v apt-get &>/dev/null; then
      sudo apt-get install -y mpg123 2>/dev/null && ok "mpg123 installed"
    elif command -v dnf &>/dev/null; then
      sudo dnf install -y mpg123 2>/dev/null && ok "mpg123 installed"
    elif command -v pacman &>/dev/null; then
      sudo pacman -S --noconfirm mpg123 2>/dev/null && ok "mpg123 installed"
    else
      err "Cannot auto-install. Run: sudo apt install mpg123"
    fi
  fi
fi

# ── Create directories ────────────────────────────────────────────
step "Creating config directory..."
mkdir -p "$INSTALL_DIR" "$SOUNDS_DIR" "$BIN_DIR"
ok "Created $INSTALL_DIR"

# ── Install sounds ────────────────────────────────────────────────
step "Installing sound files..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -n "$CUSTOM_SOUNDS" && -d "$CUSTOM_SOUNDS" ]]; then
  cp "$CUSTOM_SOUNDS"/*.mp3 "$SOUNDS_DIR/" 2>/dev/null || true
  ok "Copied sounds from $CUSTOM_SOUNDS"
elif [[ -d "$SCRIPT_DIR/sounds" ]]; then
  cp "$SCRIPT_DIR/sounds"/*.mp3 "$SOUNDS_DIR/" 2>/dev/null || true
  ok "Copied bundled sounds"
else
  warn "No sounds found. Copy your MP3 files to: $SOUNDS_DIR"
  warn "Expected filenames:"
  for f in permission_denied command_not_found connection_timeout build_failed crash generic_error; do
    echo "  $SOUNDS_DIR/${f}.mp3"
  done
fi

# List what's actually installed
INSTALLED_MP3S=$(ls "$SOUNDS_DIR"/*.mp3 2>/dev/null | wc -l | tr -d ' ')
ok "$INSTALLED_MP3S MP3 file(s) in sounds directory"

# ── Install config ────────────────────────────────────────────────
step "Writing default config..."
CONFIG_FILE="$INSTALL_DIR/config.json"
if [[ ! -f "$CONFIG_FILE" ]]; then
  cat > "$CONFIG_FILE" << 'CONF'
{
  "enabled": true,
  "volume": 0.85,
  "cooldown_ms": 3000,
  "log_errors": true,
  "show_banner": true,
  "sounds": {
    "permission_denied":  "permission_denied.mp3",
    "command_not_found":  "command_not_found.mp3",
    "connection_timeout": "connection_timeout.mp3",
    "build_failed":       "build_failed.mp3",
    "crash":              "crash.mp3",
    "generic_error":      "generic_error.mp3"
  }
}
CONF
  ok "Config written to $CONFIG_FILE"
else
  ok "Config already exists (not overwritten)"
fi

# ── Install daemon script ─────────────────────────────────────────
step "Installing Borat daemon..."
cp "$SCRIPT_DIR/borat_daemon.py" "$INSTALL_DIR/borat_daemon.py"
chmod +x "$INSTALL_DIR/borat_daemon.py"

# ── Install shell wrapper ─────────────────────────────────────────
cat > "$BIN_DIR/borat" << WRAPPER
#!/usr/bin/env bash
# Borat Terminal Error Notification — shell entry point
exec python3 "$INSTALL_DIR/borat_daemon.py" "\$@"
WRAPPER
chmod +x "$BIN_DIR/borat"
ok "Installed: $BIN_DIR/borat"

# ── Install dashboard ─────────────────────────────────────────────
if [[ -f "$SCRIPT_DIR/borat_dashboard.py" ]]; then
  cp "$SCRIPT_DIR/borat_dashboard.py" "$INSTALL_DIR/borat_dashboard.py"
  cat > "$BIN_DIR/borat-dash" << WRAPPER2
#!/usr/bin/env bash
exec python3 "$INSTALL_DIR/borat_dashboard.py" "\$@"
WRAPPER2
  chmod +x "$BIN_DIR/borat-dash"
  ok "Installed: $BIN_DIR/borat-dash"
fi

# ── PATH check ────────────────────────────────────────────────────
if [[ ":$PATH:" != *":$BIN_DIR:"* ]]; then
  warn "$BIN_DIR is not in your PATH"
  SHELL_RC=""
  case "$SHELL" in
    */zsh)  SHELL_RC="$HOME/.zshrc" ;;
    */bash) SHELL_RC="$HOME/.bashrc" ;;
    */fish) SHELL_RC="$HOME/.config/fish/config.fish" ;;
  esac
  if [[ -n "$SHELL_RC" ]]; then
    echo ""
    echo -e "${YL}  Add this to $SHELL_RC:${NC}"
    echo -e "${BD}  export PATH=\"\$HOME/.local/bin:\$PATH\"${NC}"
    echo ""
    read -rp "  Add automatically? [y/N] " yn
    if [[ "$yn" =~ ^[Yy]$ ]]; then
      echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$SHELL_RC"
      ok "Added to $SHELL_RC — restart terminal or run: source $SHELL_RC"
    fi
  fi
fi

# ── VS Code extension ─────────────────────────────────────────────
install_vscode_ext() {
  local IDE_CMD="$1"
  local IDE_NAME="$2"

  if ! command -v "$IDE_CMD" &>/dev/null; then
    warn "$IDE_NAME not found in PATH, skipping"
    return
  fi

  step "Installing $IDE_NAME extension..."
  EXT_DIR="$SCRIPT_DIR/vscode"
  if [[ ! -d "$EXT_DIR" ]]; then
    warn "VS Code extension source not found at $EXT_DIR"
    return
  fi

  if ! command -v node &>/dev/null; then
    warn "Node.js required to build extension. Install from nodejs.org"
    return
  fi

  pushd "$EXT_DIR" > /dev/null
  npm install --ignore-scripts --silent 2>/dev/null
  npx tsc -p tsconfig.json 2>/dev/null

  # Copy sounds into extension
  mkdir -p "$EXT_DIR/sounds"
  cp "$SOUNDS_DIR"/*.mp3 "$EXT_DIR/sounds/" 2>/dev/null || true

  npx @vscode/vsce package --no-dependencies --out borat-terminal.vsix 2>/dev/null
  "$IDE_CMD" --install-extension borat-terminal.vsix --force 2>/dev/null
  popd > /dev/null

  ok "$IDE_NAME extension installed"
}

if [[ "$IDE_TARGET" == "vscode" || "$IDE_TARGET" == "all" ]]; then
  install_vscode_ext "code" "VS Code"
fi

if [[ "$IDE_TARGET" == "cursor" || "$IDE_TARGET" == "all" ]]; then
  install_vscode_ext "cursor" "Cursor"
fi

# ── Shell integration (optional) ──────────────────────────────────
step "Shell integration (automatic error detection in current shell)..."
HOOK='
# Borat Terminal — auto error detection hook
_borat_check() {
  local exit_code=$?
  if [[ $exit_code -ne 0 ]] && [[ -x "$HOME/.local/bin/borat" ]]; then
    echo "exit code $exit_code" | python3 '"$INSTALL_DIR"'/borat_daemon.py --pipe 2>/dev/null &
  fi
}
[[ -n "$BORAT_TERMINAL_ACTIVE" ]] || trap '"'"'_borat_check'"'"' DEBUG
'

warn "Shell hook (optional): adds exit-code monitoring to current shell"
warn "This runs without needing to type 'borat' — just works in background"
echo ""
read -rp "  Install shell hook in your .bashrc/.zshrc? [y/N] " yn
if [[ "$yn" =~ ^[Yy]$ ]]; then
  for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
    if [[ -f "$rc" ]]; then
      if ! grep -q "borat_check" "$rc" 2>/dev/null; then
        echo "$HOOK" >> "$rc"
        ok "Shell hook added to $rc"
      else
        ok "$rc already has Borat hook"
      fi
    fi
  done
fi

# ── Done ──────────────────────────────────────────────────────────
echo ""
echo -e "${YL}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${YL}║  ✓ INSTALLATION COMPLETE — GREAT SUCCESS!                   ║${NC}"
echo -e "${YL}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BD}Usage:${NC}"
echo -e "  ${CY}borat${NC}              — Start Borat shell wrapper"
echo -e "  ${CY}borat --status${NC}     — Check installation status"
echo -e "  ${CY}borat --test crash${NC} — Test a specific sound category"
echo -e "  ${CY}borat-dash${NC}         — Live error monitoring dashboard"
echo ""
echo -e "  ${BD}Sound files:${NC} $SOUNDS_DIR"
echo -e "  ${BD}Config:${NC}      $CONFIG_FILE"
echo ""
echo -e "  ${YL}\"I will now watch your terminal. Very nice!\"${NC}"
echo ""

show_help() {
  echo "Usage: bash install.sh [options]"
  echo "Options:"
  echo "  --sounds-dir PATH   Use existing MP3 files from PATH"
  echo "  --ide vscode|cursor|all   Install IDE extension"
  echo "  --help              Show this help"
}
