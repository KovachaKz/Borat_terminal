#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║          BORAT TERMINAL ERROR NOTIFICATION DAEMON            ║
║          Kazakhstan OS — Error Detection System              ║
║          "Very Nice! Your code is NOT nice."                 ║
╚══════════════════════════════════════════════════════════════╝

Cross-platform terminal error watcher.
Wraps your shell in a PTY, intercepts all output in real-time,
matches error patterns, and plays the appropriate Borat MP3.

Architecture:
  Parent process  → PTY master (reads output, detects errors)
  Child process   → PTY slave (your real shell — bash/zsh/fish)
  Audio thread    → Fires MP3 playback on match (non-blocking)

Works identically on macOS, Linux, and Windows (WSL).
"""

import os
import sys
import pty
import re
import json
import time
import signal
import select
import struct
import termios
import fcntl
import threading
import subprocess
import logging
import hashlib
import textwrap
from pathlib import Path
from datetime import datetime
from collections import deque
from typing import Optional

# ─────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────

CONFIG_PATH = Path.home() / ".config" / "borat-terminal" / "config.json"
LOG_PATH    = Path.home() / ".config" / "borat-terminal" / "borat.log"
SOUNDS_DIR  = Path.home() / ".config" / "borat-terminal" / "sounds"

DEFAULT_CONFIG = {
    "enabled": True,
    "volume": 0.85,
    "cooldown_ms": 3000,
    "shell": os.environ.get("SHELL", "/bin/bash"),
    "log_errors": True,
    "show_banner": True,
    "sounds": {
        "permission_denied":  "permission_denied.mp3",
        "command_not_found":  "command_not_found.mp3",
        "crash":              "crash.mp3",
        "connection_timeout": "connection_timeout.mp3",
        "build_failed":       "build_failed.mp3",
        "generic_error":      "generic_error.mp3",
    }
}

# ─────────────────────────────────────────────────────────────
# Error Pattern Engine
# ─────────────────────────────────────────────────────────────

# Each pattern maps to a sound category.
# Ordered from most-specific to least-specific.
ERROR_PATTERNS = [
    # Permission / Access
    ("permission_denied", [
        r"permission denied",
        r"access denied",
        r"operation not permitted",
        r"EACCES",
        r"error.*access_denied",
        r"sudo:.*incorrect password",
        r"you do not have.*permission",
    ]),

    # Command not found
    ("command_not_found", [
        r"command not found",
        r"not found.*command",
        r"No such file or directory",
        r"cannot find.*command",
        r"is not recognized as.*command",
        r"which:.*no .* in \(",
        r"zsh:.*not found",
        r"bash:.*No such file",
    ]),

    # Network / Connection
    ("connection_timeout", [
        r"connection timed? out",
        r"connection refused",
        r"network is unreachable",
        r"no route to host",
        r"could not resolve host",
        r"name or service not known",
        r"connection reset by peer",
        r"ssl.*error",
        r"certificate.*expired",
        r"ECONNREFUSED",
        r"ETIMEDOUT",
        r"EHOSTUNREACH",
    ]),

    # Build failures
    ("build_failed", [
        r"build failed",
        r"FAILURE:.*build",
        r"compilation failed",
        r"make.*Error \d+",
        r"gradle.*FAILED",
        r"npm ERR!",
        r"yarn.*error",
        r"pip.*error",
        r"error\[E\d+\]",          # Rust
        r"error TS\d+:",            # TypeScript
        r"SyntaxError:",
        r"ModuleNotFoundError:",
        r"ImportError:",
        r"Cannot find module",
        r"COMPILE ERROR",
    ]),

    # Crash / Fatal
    ("crash", [
        r"segmentation fault",
        r"core dumped",
        r"killed",
        r"out of memory",
        r"java\.lang\.(NullPointerException|OutOfMemoryError|StackOverflowError)",
        r"fatal error",
        r"FATAL",
        r"panic:",
        r"thread.*panicked",
        r"Abort trap",
        r"Bus error",
        r"assertion.*failed",
        r"CrashLoopBackOff",
        r"OOMKilled",
        r"process exited with code [1-9]",
        r"exit code: [1-9]",
        r"exited with code [1-9]",
        r"returned non-zero",
    ]),

    # Generic catch-all (checked last)
    ("generic_error", [
        r"^\s*error:",
        r"^\s*ERROR:",
        r"^\s*Error:",
        r"FAILED$",
        r"^\[error\]",
        r"exception.*:",
        r"traceback \(most recent",
        r"AssertionError",
        r"ReferenceError",
        r"TypeError:",
        r"ValueError:",
        r"AttributeError:",
        r"KeyError:",
        r"IndexError:",
        r"RuntimeError:",
        r"IOError:",
    ]),
]

# Lines that look like errors but definitely aren't
FALSE_POSITIVES = [
    r"^\s*#",                         # shell comments
    r"error\.log",                    # filenames
    r"error\.ts",
    r"error\.js",
    r"errorHandler",
    r"\.error\s*\(",                  # console.error(
    r"error_rate",
    r"no errors",
    r"0 errors",
    r"0 error",
    r"without errors",
    r"fixed.*error",
    r"catch\s*\(",                    # catch blocks
    r"rescue\s+",                     # Ruby rescue
    r"except\s+",                     # Python except (the keyword line, not the exception)
    r"^--",                           # argument flags
    r"^\s*\^",                        # caret pointer lines under errors
    r"\x1b\[",                        # raw ANSI codes in pattern match (strip these first)
]

# ─────────────────────────────────────────────────────────────
# Compiled regex cache
# ─────────────────────────────────────────────────────────────

_compiled_patterns: list[tuple[str, list[re.Pattern]]] = []
_compiled_fp: list[re.Pattern] = []

def _compile_patterns():
    global _compiled_patterns, _compiled_fp
    _compiled_patterns = [
        (cat, [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in patterns])
        for cat, patterns in ERROR_PATTERNS
    ]
    _compiled_fp = [re.compile(p, re.IGNORECASE) for p in FALSE_POSITIVES]

_compile_patterns()

ANSI_ESCAPE = re.compile(r'\x1b\[[0-9;]*[mGKHF]|\x1b\][^\x07]*\x07|\x1b[()][AB012]')

def strip_ansi(text: str) -> str:
    return ANSI_ESCAPE.sub('', text)

def detect_error(chunk: str) -> Optional[str]:
    """
    Scan a chunk of terminal output for error patterns.
    Returns the sound category name, or None if clean.
    """
    clean = strip_ansi(chunk)
    lines = clean.split('\n')

    for line in lines:
        stripped = line.strip()
        if len(stripped) < 4:
            continue

        # Check false positives
        is_fp = any(fp.search(stripped) for fp in _compiled_fp)
        if is_fp:
            continue

        # Check each error category (most specific first)
        for category, patterns in _compiled_patterns:
            for pattern in patterns:
                if pattern.search(stripped):
                    return category

    return None

# ─────────────────────────────────────────────────────────────
# Audio Player
# ─────────────────────────────────────────────────────────────

class AudioPlayer:
    """
    Cross-platform MP3 playback via native OS tools.
    Non-blocking: spawns detached child process.
    Cooldown-aware: drops rapid-fire duplicate plays.
    """

    def __init__(self):
        self._last_played: float = 0.0
        self._last_category: str = ""
        self._lock = threading.Lock()
        self._active_proc: Optional[subprocess.Popen] = None
        self._platform = sys.platform

    def play(self, sound_path: Path, volume: float, cooldown_ms: int, category: str) -> bool:
        """
        Play an MP3 file. Returns True if playback was triggered.
        """
        with self._lock:
            now = time.time()
            elapsed_ms = (now - self._last_played) * 1000

            if elapsed_ms < cooldown_ms:
                return False  # Cooldown active

            if not sound_path.exists():
                logging.warning(f"Sound file not found: {sound_path}")
                return False

            self._last_played = now
            self._last_category = category

            # Kill previous if still running
            if self._active_proc and self._active_proc.poll() is None:
                try:
                    self._active_proc.terminate()
                except Exception:
                    pass

            cmd = self._build_command(sound_path, volume)
            if not cmd:
                return False

            try:
                proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    close_fds=True,
                )
                self._active_proc = proc
                return True
            except FileNotFoundError:
                logging.error(f"Audio player not found: {cmd[0]}")
                return False
            except Exception as e:
                logging.error(f"Audio playback failed: {e}")
                return False

    def _build_command(self, path: Path, volume: float) -> Optional[list]:
        p = str(path)

        if self._platform == "darwin":
            # afplay: volume is 0.0-1.0 (--volume flag needs 0-255 scale on some versions)
            return ["afplay", "-v", f"{volume:.2f}", p]

        elif self._platform.startswith("linux"):
            # Try mpg123 first, then paplay, then ffplay
            for player in ["mpg123", "paplay", "ffplay"]:
                if self._which(player):
                    if player == "mpg123":
                        gain = int(volume * 32768)
                        return ["mpg123", "-q", "--scale", str(gain), p]
                    elif player == "paplay":
                        vol = int(volume * 65536)
                        return ["paplay", f"--volume={vol}", p]
                    elif player == "ffplay":
                        vol = int(volume * 100)
                        return ["ffplay", "-nodisp", "-autoexit",
                                "-volume", str(vol), "-loglevel", "quiet", p]
            logging.error("No audio player found. Run: sudo apt install mpg123")
            return None

        elif self._platform == "win32":
            escaped = p.replace("'", "''")
            script = (
                f"Add-Type -AssemblyName PresentationCore; "
                f"$p=New-Object System.Windows.Media.MediaPlayer; "
                f"$p.Open([Uri]::new('{escaped}')); "
                f"$p.Volume={volume:.2f}; "
                f"Start-Sleep -Ms 300; $p.Play(); "
                f"Start-Sleep -Sec 60; $p.Close();"
            )
            return ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", script]

        return None

    @staticmethod
    def _which(cmd: str) -> bool:
        try:
            subprocess.run(["which", cmd], capture_output=True, check=True)
            return True
        except Exception:
            return False

    def stop(self):
        if self._active_proc and self._active_proc.poll() is None:
            try:
                self._active_proc.terminate()
            except Exception:
                pass

# ─────────────────────────────────────────────────────────────
# Stats tracker
# ─────────────────────────────────────────────────────────────

class ErrorStats:
    def __init__(self):
        self.total = 0
        self.by_category: dict[str, int] = {}
        self.recent: deque = deque(maxlen=20)
        self._lock = threading.Lock()

    def record(self, category: str, line_snippet: str):
        with self._lock:
            self.total += 1
            self.by_category[category] = self.by_category.get(category, 0) + 1
            self.recent.append({
                "ts": datetime.now().strftime("%H:%M:%S"),
                "category": category,
                "snippet": line_snippet[:80],
            })

# ─────────────────────────────────────────────────────────────
# Config manager
# ─────────────────────────────────────────────────────────────

def load_config() -> dict:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    if CONFIG_PATH.exists():
        try:
            with open(CONFIG_PATH) as f:
                stored = json.load(f)
            # Merge with defaults so new keys always exist
            merged = {**DEFAULT_CONFIG, **stored}
            merged["sounds"] = {**DEFAULT_CONFIG["sounds"], **stored.get("sounds", {})}
            return merged
        except Exception:
            pass
    # Write defaults on first run
    with open(CONFIG_PATH, "w") as f:
        json.dump(DEFAULT_CONFIG, f, indent=2)
    return dict(DEFAULT_CONFIG)

def resolve_sound(config: dict, category: str) -> Optional[Path]:
    """Find the MP3 for a given category. Falls back gracefully."""
    sounds = config.get("sounds", {})

    # Direct category match
    filename = sounds.get(category)
    if filename:
        p = SOUNDS_DIR / filename
        if p.exists():
            return p

    # Fallback to generic_error
    fallback = sounds.get("generic_error")
    if fallback:
        p = SOUNDS_DIR / fallback
        if p.exists():
            return p

    # Last resort: any .mp3 in sounds dir
    mp3s = list(SOUNDS_DIR.glob("*.mp3"))
    if mp3s:
        return mp3s[0]

    return None

# ─────────────────────────────────────────────────────────────
# PTY Shell Wrapper — the core interception layer
# ─────────────────────────────────────────────────────────────

class BoratShell:
    """
    Wraps the user's shell in a PTY.
    Reads all output, detects errors, fires audio.
    Transparent: the user sees exactly what they'd normally see.
    """

    def __init__(self, config: dict):
        self.config = config
        self.audio = AudioPlayer()
        self.stats = ErrorStats()
        self._running = True
        self._setup_logging()

    def _setup_logging(self):
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(
            filename=str(LOG_PATH),
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(message)s",
        )

    def _get_terminal_size(self) -> tuple[int, int]:
        try:
            size = os.get_terminal_size()
            return size.rows, size.columns
        except Exception:
            return 24, 80

    def _set_pty_size(self, fd: int):
        rows, cols = self._get_terminal_size()
        size = struct.pack("HHHH", rows, cols, 0, 0)
        fcntl.ioctl(fd, termios.TIOCSWINSZ, size)

    def run(self):
        shell = self.config.get("shell", os.environ.get("SHELL", "/bin/bash"))

        if self.config.get("show_banner"):
            self._print_banner()

        # Fork into PTY
        pid, master_fd = pty.fork()

        if pid == 0:
            # ── Child: exec the real shell ───────────────────────────
            os.execvp(shell, [shell])
            sys.exit(1)

        # ── Parent: intercept I/O ────────────────────────────────────
        self._set_pty_size(master_fd)

        # Forward SIGWINCH (terminal resize) to child
        def handle_resize(signum, frame):
            self._set_pty_size(master_fd)
            try:
                os.kill(pid, signal.SIGWINCH)
            except Exception:
                pass

        signal.signal(signal.SIGWINCH, handle_resize)

        # Save terminal state, set raw mode
        old_attrs = termios.tcgetattr(sys.stdin.fileno())
        try:
            import tty
            tty.setraw(sys.stdin.fileno())
        except Exception:
            pass

        # Buffer for multi-line error detection
        output_buffer = ""
        buffer_timer = 0.0
        BUFFER_FLUSH_INTERVAL = 0.08  # seconds

        try:
            while self._running:
                try:
                    r, _, _ = select.select([sys.stdin, master_fd], [], [], 0.05)
                except (ValueError, OSError):
                    break

                # ── stdin → PTY (user keystrokes) ────────────────────
                if sys.stdin in r:
                    try:
                        data = os.read(sys.stdin.fileno(), 1024)
                        os.write(master_fd, data)
                    except OSError:
                        break

                # ── PTY → stdout (shell output) ──────────────────────
                if master_fd in r:
                    try:
                        data = os.read(master_fd, 4096)
                    except OSError:
                        break

                    # Write raw bytes to terminal (preserves colors, etc.)
                    os.write(sys.stdout.fileno(), data)

                    # Accumulate decoded output for error detection
                    try:
                        output_buffer += data.decode('utf-8', errors='replace')
                    except Exception:
                        pass

                    buffer_timer = time.time()

                # ── Flush buffer for error detection ─────────────────
                now = time.time()
                if output_buffer and (now - buffer_timer) >= BUFFER_FLUSH_INTERVAL:
                    if self.config.get("enabled", True):
                        self._check_output(output_buffer)
                    output_buffer = ""

                # ── Check if child exited ─────────────────────────────
                try:
                    result = os.waitpid(pid, os.WNOHANG)
                    if result[0] != 0:
                        # Flush remaining buffer
                        if output_buffer and self.config.get("enabled", True):
                            self._check_output(output_buffer)
                        break
                except ChildProcessError:
                    break

        finally:
            # Restore terminal state
            try:
                termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old_attrs)
            except Exception:
                pass
            self.audio.stop()
            os.close(master_fd)

    def _check_output(self, text: str):
        """Run error detection and trigger audio if matched."""
        category = detect_error(text)
        if not category:
            return

        # Extract a clean snippet for logging
        clean = strip_ansi(text)
        snippet = next(
            (ln.strip() for ln in clean.splitlines() if ln.strip()),
            text[:60]
        )

        self.stats.record(category, snippet)
        logging.info(f"Error detected [{category}]: {snippet[:100]}")

        # Resolve sound file
        sound_path = resolve_sound(self.config, category)
        if not sound_path:
            logging.warning(f"No sound file for category: {category}")
            return

        volume    = float(self.config.get("volume", 0.85))
        cooldown  = int(self.config.get("cooldown_ms", 3000))

        played = self.audio.play(sound_path, volume, cooldown, category)
        if played:
            logging.info(f"Played: {sound_path.name}")

    def _print_banner(self):
        banner = """
\033[33m╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   🇰🇿  BORAT TERMINAL ERROR NOTIFICATION SYSTEM  🇰🇿         ║
║                                                              ║
║   "I will watch your terminal output. Very nice."           ║
║                                                              ║
║   Errors detected  → Borat speaks                           ║
║   Type 'exit' to leave Kazakhstan OS                        ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝\033[0m
"""
        print(banner)


# ─────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────

def main():
    config = load_config()

    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "--status":
            print_status(config)
            return
        elif cmd == "--test":
            category = sys.argv[2] if len(sys.argv) > 2 else "generic_error"
            test_sound(config, category)
            return
        elif cmd == "--config":
            print(f"Config: {CONFIG_PATH}")
            print(json.dumps(config, indent=2))
            return
        elif cmd == "--help":
            print_help()
            return

    shell = BoratShell(config)
    shell.run()


def print_status(config: dict):
    print("\n\033[33m═══ BORAT TERMINAL STATUS ═══\033[0m")
    print(f"  Enabled  : {'✓ YES' if config['enabled'] else '✗ NO'}")
    print(f"  Volume   : {config['volume']}")
    print(f"  Cooldown : {config['cooldown_ms']}ms")
    print(f"  Shell    : {config['shell']}")
    print(f"  Config   : {CONFIG_PATH}")
    print(f"  Sounds   : {SOUNDS_DIR}")
    print("\n  Installed sounds:")
    for cat, fname in config["sounds"].items():
        path = SOUNDS_DIR / fname
        status = "✓" if path.exists() else "✗"
        print(f"    {status} [{cat}] → {fname}")
    print()


def test_sound(config: dict, category: str):
    print(f"\033[33mTesting sound for category: {category}\033[0m")
    player = AudioPlayer()
    sound_path = resolve_sound(config, category)
    if not sound_path:
        print(f"\033[31mNo sound file found for '{category}'\033[0m")
        print(f"Place MP3 files in: {SOUNDS_DIR}")
        return
    print(f"Playing: {sound_path.name}")
    player.play(sound_path, float(config["volume"]), 0, category)
    time.sleep(3)


def print_help():
    print("""
BORAT TERMINAL — Kazakhstan OS Error Notification System

Usage:
  borat                    Start Borat shell (wraps your default shell)
  borat --status           Show current configuration and sound files
  borat --test [category]  Test a specific sound
  borat --config           Show config file path and contents
  borat --help             Show this help

Sound categories:
  permission_denied    command_not_found    connection_timeout
  build_failed         crash                generic_error

Config file: ~/.config/borat-terminal/config.json
Sound files: ~/.config/borat-terminal/sounds/
""")


if __name__ == "__main__":
    main()
